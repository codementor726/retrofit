package io.socket.socketio.server.parser;

public class DecodingException extends RuntimeException {

    public DecodingException(String message) {
        super(message);
    }
}
