.. Socket.IO documentation master file, created by
   sphinx-quickstart on Thu Aug  9 18:55:12 2018.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to Socket.IO Java Server's documentation!
=================================================

.. toctree::
   :maxdepth: 1
   :caption: Contents:

   install
   using
   api
   javadocs/index
