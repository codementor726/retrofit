package io.socket.client;

/**
 * Acknowledgement.
 */
public interface Ack {

    void call(Object... args);

}

